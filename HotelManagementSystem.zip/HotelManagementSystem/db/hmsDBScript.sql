
//Create User Table
CREATE TABLE user (user_id varchar(4) PRIMARY KEY, 
password varchar(7),
role varchar(10), 
user_name varchar(20) UNIQUE,
mobile_no varchar(10),
phone varchar(10),
address varchar(25), 
email varchar(15));

//Create Hotel Table
CREATE TABLE hotel (hotelId number(7),
city varchar(10),
hotelName varchar (20),
address varchar(25),
description varchar(50),
avgRatePerNight number(5,2),
phoneNo1 varchar(10),
phoneNo2 varchar(10),
rating varchar(6),
email varchar(15),
fax varchar(15));


//Create RoomDetails Table
CREATE TABLE roomdetails (hotel_id varchar(4), 
room_id varchar(4), 
room_no varchar(3),
room_type varchar(20),
per_night_rate number(6,2),
availability varchar(4));

//Create BookingDetails Table
CREATE TABLE bookingdetails (booking_id varchar(4),
room_id varchar(4),
user_id varchar(4),
booked_from date,
booked_to date,
no_of_adults number(3),
no_of_children number(3),
amount number(6,2));

//Insert into Hotel Table
INSERT INTO Hotel (hotelId, hotelName, city) values (1001,'Marriot','Bangalore');
INSERT INTO Hotel (hotelId, hotelName, city) values (1002,'TAJ','Mumbai');
INSERT INTO Hotel (hotelId, hotelName, city) values (1003,'Trident','Mumbai');
