package com.cg.hms.ui;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.cg.hms.bean.Hotel;
import com.cg.hms.exception.HMSException;
import com.cg.hms.service.HotelServiceImpl;
import com.cg.hms.service.IHotelService;


public class CustomerConsole {
	private String currentUser;
	private IHotelService hotelService;
	private Scanner scan;
	
	public CustomerConsole(String currentUser) {
		this.currentUser = currentUser;
	}
	public void start() {
		scan = new Scanner(System.in);
		hotelService = new HotelServiceImpl();
		System.out.println("Welcome "+currentUser);
		System.out.println("customer");

		int choice = -1;

		while (choice != 2) {

			System.out
					.println("[1]Reserve Hotel [2]LogOut");
			System.out.print("Choice> ");
			choice = scan.nextInt();
			
			switch(choice){
			case 1:reserveHotel();break;
			}
		}
	}
	public void reserveHotel() {
		System.out.println("Reserve Hotel");
		List<Hotel> hotels;
		try {
			hotels = hotelService.listHotels();
		
		if (hotels != null) {
			System.out.println("\tHotel Id\tHotel Name\tCity");
			System.out.println("-------------------------------------------");
			for (Hotel hotel : hotels) {
				System.out
						.println("\t" +hotel.getHotelId()+"\t\t"+ hotel.getHotelName()+"\t\t"+hotel.getCity());
				}
			System.out.print("HotelCode> ");
			String hcode=scan.next();
			
			Hotel hotel = hotelService.findHotel(hcode);
		}
		else {
			System.out.println("No Records Found!");
		}
		}
		catch (HMSException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
		}
	}
}
