package com.cg.hms.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;
import com.cg.hms.service.AdminServiceImpl;
import com.cg.hms.service.HotelServiceImpl;
import com.cg.hms.service.IAdminService;
import com.cg.hms.service.IHotelService;

public class AdminConsole {

	private String currentUser;
	private IHotelService hotelService;
	private IAdminService adminService = new AdminServiceImpl();
	private Scanner scan = new Scanner(System.in);

	public AdminConsole(String currentUser) {
		this.currentUser = currentUser;
	}

	public void start() {
		scan = new Scanner(System.in);
		hotelService = new HotelServiceImpl();
		System.out.println("Welcome " + currentUser);
		System.out.println("admin");

		int choice = 0;

		while (choice != 4) {

			System.out
					.println("[1]Show Hotels [2]Add Hotel [3]Delete Hotel [4] Modify Hotel \n"
							+ "[5] Add Rooms [6] Delete Rooms [7] Modify Rooms \n"
							+ "[8]LogOut");
			System.out.print("Choice> ");
			choice = scan.nextInt();

			switch (choice) {
			case 1:
				reserveHotel();
				break;

			case 2:
				addHotel();
				break;

			case 3:
				deleteHotel();
				break;

			case 4:
				modifyHotel();
				break;
				
			case 5:
				addRooms();
				break;
				
			case 6:
				deleteRoom();
				break;
				
			case 8:
				modifyHotel();
				break;
			case 9:
				modifyHotel();
				break;
			}
			System.out.println("end admin console");
		}
	}

	

	public void reserveHotel() {
		System.out.println("Reserve Hotel");
		List<Hotel> hotels;
		try {
			hotels = hotelService.listHotels();

			if (hotels != null) {

				String leftAlignFormat = "| %-15s | %-15s | %-15s | %-15s | %-15s | %-8s |%n";

				System.out
						.format("+-----------------+-----------------+-----------------+-----------------+-----------------+----------+%n");
				System.out
						.format("| Hotel Id        | Hotel Name      | City            | Description     | Avg rate/night  | Rating   |%n");
				System.out
						.format("+-----------------+-----------------+-----------------+-----------------+-----------------+----------+%n");
				for (Hotel hotel : hotels) {
					System.out.format(leftAlignFormat, hotel.getHotelId(),
							hotel.getHotelName(), hotel.getCity(),
							hotel.getDescription(), hotel.getAvgRatePerNight(),
							hotel.getRating());
				}
				System.out
						.format("+-----------------+-----------------+-----------------+-----------------+-----------------+----------+%n");

			} else {
				System.out.println("No Records Found!");
			}
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		}
	}

	public void addHotel() {
		// instantiate hotel and add hotel
		Hotel hotel = new Hotel();
		String hotelName, city, desc, rating, address, phone01, phone02, email, fax;
		int hotelId;
		double avgPerNight;
		System.out.println("Enter Hotel ID(number)");
		hotelId = scan.nextInt();

		System.out.println("Enter Hotel Name");
		hotelName = scan.next();

		System.out.println("Enter Hotel city");
		city = scan.next();

		System.out.println("Enter Hotel description");
		desc = scan.next();

		System.out.println("Enter Hotel rating");
		rating = scan.next();
		rating += "★";

		System.out.println("Enter Hotel rate per night ");
		avgPerNight = scan.nextDouble();

		System.out.println("Enter Hotel address ");
		address = scan.next();
		System.out.println("Enter Hotel Phone ");
		phone01 = scan.next();
		System.out.println("Enter Hotel alternative phone no. ");
		phone02 = scan.next();
		System.out.println("Enter Hotel email ");
		email = scan.next();
		System.out.println("Enter Hotel alternative fax ");
		fax = scan.next();

		hotel.setHotelName(hotelName);
		hotel.setHotelId(hotelId);
		hotel.setCity(city);
		hotel.setDescription(desc);
		hotel.setRating(rating);
		hotel.setAddress(address);
		hotel.setPhoneNo1(phone01);
		hotel.setPhoneNo2(phone02);
		hotel.setEmail(email);
		hotel.setFax(fax);
		hotel.setAvgRatePerNight(avgPerNight);// to be set after adding rooms
												// only

		addRooms();

		try {
			System.out.println("hotel added " + adminService.addHotel(hotel));
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		}
	}

	private void addRooms() {
		//calculate avg per night---if hotelid doesn't exist	
		String roomType, availabilty;
		int hotelId, roomId, roomNo, perNightPrice;
		Room room = new Room();
		int ans;
		System.out.println("Enter hotel id(number)");
		hotelId = scan.nextInt();
		System.out.println("Enter room id(number)");
		roomId = scan.nextInt();
		System.out.println("Room type [1] AC [2] Non-AC [3] Delux AC ");
		ans= scan.nextInt();
		if(ans==1) roomType="AC";
		else if(ans==1) roomType="Non-AC";
		else roomType="Delux AC";
		System.out.println("Enter price per night");
		perNightPrice = scan.nextInt();
		System.out.println("Enter room no ");
		roomNo = scan.nextInt();
		String hcode;
//		hcode=(String)hotelId;
//		Hotel hoteltmp = hotelService.findHotel();

		room.setAvailable("yes");
		room.setHotelId(hotelId);
		room.setPerNightPrice(perNightPrice);
		room.setRoomNo(roomNo);
		room.setRoomId(roomId);
		room.setRoomType(roomType);
		try {
			System.out.println("Room added " + adminService.addRoom(room));

		} catch (HMSException e) {
			System.err.println(e.getMessage());
		}
	}
	
private void deleteRoom() {
	reserveHotel();
	System.out.println("enter the hotel id:");
	int id = scan.nextInt();
	try {
		System.out.println("hotel deleted " + adminService.deleteHotel(id));
	} catch (HMSException e) {
		System.err.println(e.getMessage());
	}
	}

	public void deleteHotel() {
		reserveHotel();
		System.out.println("enter the hotel id:");
		int id = scan.nextInt();
		try {
			System.out.println("hotel deleted " + adminService.deleteHotel(id));
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		}

	}

	public void modifyHotel() {
		reserveHotel();
		System.out.println("enter the hotel id to modify: ");
		int id = scan.nextInt();
		try {
			System.out.println("hotel deleted " + adminService.modifyHotel(id));
		} catch (HMSException e) {
			System.err.println(e.getMessage());
		}

	}

}
