package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.hms.bean.User;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

public class UserDAOImpl implements IUserDAO{
	
	@Override
	public User getUserByName(String userName) throws HMSException {
		User user = null;
		try(
				Connection con = DbUtil.getConnection();
				PreparedStatement st = con.prepareStatement(IQueryMapper.GET_USER)
			){
			
			st.setString(1, userName);
			
			ResultSet rs = st.executeQuery();
			if(rs.next()){
				user = new User();
				user.setUserName(rs.getString(1));
				user.setPassword(rs.getString(2));
				user.setRole(rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace(); //Remove this later
			throw new HMSException("Unable To Fetch Records");
		}
		return user;
	}

}
