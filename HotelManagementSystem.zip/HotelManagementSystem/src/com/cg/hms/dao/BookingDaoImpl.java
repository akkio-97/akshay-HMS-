package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.hms.bean.Booking;
import com.cg.hms.exception.HMSException;
import com.cg.hms.service.IBookingService;
import com.cg.hms.util.DbUtil;

public class BookingDaoImpl implements IBookingDao {

	@Override
	public boolean saveBooking(Booking book) throws HMSException {
		boolean bcode = false;
		if (book != null) {
			try (Connection conn = DbUtil.getConnection();
					PreparedStatement st = conn.prepareStatement(IQueryMapper.ADD_BOOKING);) {
				
				st.setInt(1, book.getBookingId());
				st.setInt(2, book.getRoomId());
				st.setDate(3, book.getfDate());
				st.setDate(4, book.gettDate());
				st.setInt(5, book.getAdults());
				st.setInt(6, book.getChild());
				st.setDouble(7, book.getAmount());
				int count = st.executeUpdate();

				if (count > 0)
					bcode = true;

			} catch (SQLException e) {
//				log.error(e);
				throw new HMSException("Unable To Save Booking");
			}
		}
		return bcode;
	}

}
