package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

public class AdminDaoImpl implements IAdminDao {
	public int addHotel(Hotel hotel) throws HMSException{
		int n;
		
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn
						.prepareStatement(IQueryMapper.ADD_HOTEL);) {

			st.setInt(1, hotel.getHotelId());
			st.setString(2, hotel.getCity());
			st.setString(3, hotel.getHotelName());
			st.setString(4, hotel.getAddress());
			st.setString(5, hotel.getDescription());
			st.setDouble(6, hotel.getAvgRatePerNight());
			st.setString(7, hotel.getPhoneNo1());
			st.setString(8, hotel.getPhoneNo2());
			st.setString(9, hotel.getRating());
			st.setString(10, hotel.getEmail());
			st.setString(11, hotel.getFax());
			
			n = st.executeUpdate();



		} catch (SQLException e) {
			e.printStackTrace();
			throw new HMSException("Unable To Fetch Hotels");
		}

		return n;
	}

	@Override
	public int deleteHotel(int hotelId) throws HMSException {

		int n=0;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn
						.prepareStatement(IQueryMapper.DELETE_HOTEL);) {

			st.setInt(1, hotelId);		
			n = st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace(); 
			throw new HMSException("Unable To Fetch Hotels");
		}
		
		System.out.println("finished delete hotel dao ");
		return n;
	}

	@Override
	public int modifyHotel(int hotelId) throws HMSException {
		int n=0;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn
						.prepareStatement(IQueryMapper.MODIFY_HOTEL);) {

			System.out.println("Provide description: ");
			Scanner scan = new Scanner(System.in);
			String desc= scan.next();
			st.setString(1, desc);
			st.setInt(2, hotelId);		
			n = st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace(); 
			throw new HMSException("Unable To Fetch Hotels");
		}
		
		System.out.println("finished delete hotel dao ");
		return n;
	}

	@Override
	public int addRoom(Room room) throws HMSException {
		System.out.println("reached addroom");
		System.out.println("inside roomDao");
		System.out.println(room);
		int n;
		
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn
						.prepareStatement(IQueryMapper.ADD_ROOM);) {

			st.setInt(1, room.getHotelId());
			st.setInt(2, room.getRoomId());
			st.setInt(3, room.getRoomNo());
			st.setString(4, room.getRoomType());
			st.setDouble(5, room.getPerNightPrice());
			st.setString(6, room.getAvailable());
			
			n = st.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace(); 
			throw new HMSException("Unable To Fetch Hotels");
		}

		return n;
	}

	@Override
	public int deleteRoom(int roomId) throws HMSException {
		System.out.println("reached delete room");
		return 0;
	}

	@Override
	public int modifyRoom(int roomId) throws HMSException {
		System.out.println("reached modify room");
		return 0;
	}
	


}
