package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.hms.bean.Hotel;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

public class AdminDaoImpl implements IAdminDao {
	public int addHotel(Hotel hotel) throws HMSException{
		System.out.println("inside hotelDao");
		System.out.println(hotel);
		int n;
		
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn
						.prepareStatement(IQueryMapper.ADD_HOTEL);) {

			st.setInt(1, hotel.getHotelId());
			st.setString(2, hotel.getHotelName());
			st.setString(3, hotel.getAddress());
			n = st.executeUpdate();



		} catch (SQLException e) {
			e.printStackTrace(); // remove this later
			throw new HMSException("Unable To Fetch Hotels");
		}

		return n;
	}

	@Override
	public int deleteHotel(int hotelId) throws HMSException {

		int n=0;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn
						.prepareStatement(IQueryMapper.DELETE_HOTEL);) {

			st.setInt(1, hotelId);		
			n = st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace(); // remove this later
			throw new HMSException("Unable To Fetch Hotels");
		}
		
		System.out.println("finished delete hotel dao ");
		return n;
	}

	@Override
	public int modifyHotel(int hotelId) throws HMSException {
		int n=0;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn
						.prepareStatement(IQueryMapper.MODIFY_HOTEL);) {

			System.out.println("Provide description: ");
			Scanner scan = new Scanner(System.in);
			String desc= scan.next();
			st.setString(1, desc);
			st.setInt(2, hotelId);		
			n = st.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace(); // remove this later
			throw new HMSException("Unable To Fetch Hotels");
		}
		
		System.out.println("finished delete hotel dao ");
		return n;
	}
}
