package com.cg.hms.service;

import com.cg.hms.bean.User;
import com.cg.hms.dao.IUserDAO;
import com.cg.hms.dao.UserDAOImpl;
import com.cg.hms.exception.HMSException;

public class UserServiceImpl implements IUserService {
private IUserDAO dao = new UserDAOImpl();
	
	@Override
	public String getRole(String userName, String password) throws HMSException  {
		// TODO Auto-generated method stub
		String role=null;
		User user = dao.getUserByName(userName);
		if(user==null)
			throw new HMSException("No Such UserName");
		else if(!password.equals(user.getPassword()))
			throw new HMSException("Password Mismatch");
		else
			role=user.getRole();
		return role;
	}
}
