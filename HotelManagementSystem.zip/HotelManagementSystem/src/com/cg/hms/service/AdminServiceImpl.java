package com.cg.hms.service;

import com.cg.hms.bean.Hotel;
import com.cg.hms.dao.AdminDaoImpl;
import com.cg.hms.dao.IAdminDao;
import com.cg.hms.exception.HMSException;

public class AdminServiceImpl implements IAdminService {

	@Override
	public int addHotel(Hotel hotel) throws HMSException{
		IAdminDao adminDao = new AdminDaoImpl();
		return adminDao.addHotel(hotel);

	}

	@Override
	public int modifyHotel(int hotelId) throws HMSException{
		IAdminDao adminDao = new AdminDaoImpl();
		return adminDao.modifyHotel(hotelId);
		
	}

	@Override
	public int deleteHotel(int hotelId) throws HMSException{
		IAdminDao adminDao = new AdminDaoImpl();
		return adminDao.deleteHotel(hotelId);	
	}

}
