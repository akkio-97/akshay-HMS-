package com.cg.hms.service;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.dao.AdminDaoImpl;
import com.cg.hms.dao.IAdminDao;
import com.cg.hms.exception.HMSException;

public class AdminServiceImpl implements IAdminService {
	IAdminDao adminDao = new AdminDaoImpl();

	@Override
	public int addHotel(Hotel hotel) throws HMSException {
		return adminDao.addHotel(hotel);

	}

	@Override
	public int modifyHotel(int hotelId) throws HMSException {
		return adminDao.modifyHotel(hotelId);

	}

	@Override
	public int deleteHotel(int hotelId) throws HMSException {
		return adminDao.deleteHotel(hotelId);
	}

	@Override
	public int addRoom(Room room) throws HMSException {
		return adminDao.addRoom(room);
	}

	@Override
	public int modifyRoomAvailability(int roomId, String value) throws HMSException {
		return adminDao.modifyRoomAvailability(roomId, value);
	}

	@Override
	public int deleteRoom(int roomId) throws HMSException {
		return adminDao.deleteRoom(roomId);
	}

	@Override
	public int modifyRoomRate(int roomId, int value) throws HMSException {
		return adminDao.modifyRoomRate(roomId, value);
		
	}

 

}
