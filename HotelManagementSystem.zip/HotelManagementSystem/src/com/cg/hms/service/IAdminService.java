package com.cg.hms.service;

import com.cg.hms.bean.Hotel;
import com.cg.hms.exception.HMSException;


public interface IAdminService {
//add
//delete
//modify
public int addHotel(Hotel hotel) throws HMSException;
public int modifyHotel(int hotelId) throws HMSException;
public int deleteHotel(int hotelId) throws HMSException;
}
