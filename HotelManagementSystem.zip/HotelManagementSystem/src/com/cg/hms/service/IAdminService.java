package com.cg.hms.service;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;


public interface IAdminService {
public int addHotel(Hotel hotel) throws HMSException;
public int modifyHotel(int hotelId) throws HMSException;
public int deleteHotel(int hotelId) throws HMSException;

public int addRoom(Room room) throws HMSException;
public int modifyRoom(int roomId) throws HMSException;
public int deleteRoom(int roomId) throws HMSException;
}
