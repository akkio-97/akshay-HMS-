package com.cg.hms.service;

import com.cg.hms.bean.Booking;
import com.cg.hms.exception.HMSException;

public interface IBookingService {

	boolean saveBooking(Booking book) throws HMSException;

}
