package com.cg.hms.service;

import java.util.List;

import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;

public interface IRoomService {

	List<Room> findRoom(String hcode) throws HMSException;

}
