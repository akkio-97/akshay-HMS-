package com.cg.hms.service;

import java.util.List;

import com.cg.hms.bean.Hotel;
import com.cg.hms.dao.HotelDAOImpl;
import com.cg.hms.dao.IHotelDAO;
import com.cg.hms.exception.HMSException;

public class HotelServiceImpl implements IHotelService{

	private IHotelDAO hotelDao;
	
	public HotelServiceImpl() {
		hotelDao = new HotelDAOImpl();
	}

	@Override
	public List<Hotel> listHotels() throws HMSException {
		// TODO Auto-generated method stub
		return hotelDao.listHotels();
	}

	@Override
	public Hotel findHotel(int hcode) throws HMSException {
		// TODO Auto-generated method stub
		return hotelDao.findHotel(hcode);
	}

}
